import React from 'react'
import styles from './Counter.module.css'

const Counter = () => (
  <div className={styles.wrapper}>
    <div />
  </div>
)
